// Viana Studio© By Rasya
#include "wa/creds.hpp"

#include <sys/stat.h>

#include <charconv>
#include <cstdio>
#include <fstream>
#include <map>
#include <sstream>

#include "wa/xeddsa.hpp"

namespace wa {
namespace {

Result<std::uint32_t> parse_u32(const std::map<std::string, std::string>& kv, const std::string& key) {
    const auto it = kv.find(key);
    if (it == kv.end()) return fail("creds: field hilang: " + key);
    std::uint32_t v = 0;
    const auto& s = it->second;
    const auto [p, ec] = std::from_chars(s.data(), s.data() + s.size(), v);
    if (ec != std::errc{} || p != s.data() + s.size()) return fail("creds: angka tidak valid: " + key);
    return v;
}

}  // namespace

Result<Creds> generate_creds() {
    Creds c;
    auto noise = crypto::x25519_generate();
    auto ident = crypto::x25519_generate();
    auto spk = crypto::x25519_generate();
    auto pairing = crypto::x25519_generate();
    if (!noise) return std::unexpected(noise.error());
    if (!ident) return std::unexpected(ident.error());
    if (!spk) return std::unexpected(spk.error());
    if (!pairing) return std::unexpected(pairing.error());
    c.noise_key = std::move(*noise);
    c.identity_key = std::move(*ident);
    c.signed_prekey = std::move(*spk);
    c.pairing_ephemeral = std::move(*pairing);

    Bytes spk_msg{0x05};
    spk_msg.insert(spk_msg.end(), c.signed_prekey.pub.begin(), c.signed_prekey.pub.end());
    auto sig = crypto::xeddsa_sign(c.identity_key.priv, spk_msg);
    if (!sig) return std::unexpected(sig.error());
    c.signed_prekey_sig = std::move(*sig);

    const Bytes r = crypto::random_bytes(2);
    c.registration_id = ((std::uint32_t(r[0]) << 8) | r[1]) & 16383u;
    c.adv_secret_key = crypto::random_bytes(32);
    return c;
}

Result<void> save_creds(const Creds& c, const std::string& path) {
    std::ostringstream o;
    auto put = [&](std::string_view k, std::string_view v) { o << k << '=' << v << '\n'; };
    auto puth = [&](std::string_view k, const Bytes& v) { put(k, to_hex(v)); };

    o << "# wacpp creds - rahasia, jangan dibagikan\n";
    puth("noise_priv", c.noise_key.priv);
    puth("noise_pub", c.noise_key.pub);
    puth("identity_priv", c.identity_key.priv);
    puth("identity_pub", c.identity_key.pub);
    puth("pairing_priv", c.pairing_ephemeral.priv);
    puth("pairing_pub", c.pairing_ephemeral.pub);
    puth("spk_priv", c.signed_prekey.priv);
    puth("spk_pub", c.signed_prekey.pub);
    put("spk_id", std::to_string(c.signed_prekey_id));
    puth("spk_sig", c.signed_prekey_sig);
    put("reg_id", std::to_string(c.registration_id));
    puth("adv_secret", c.adv_secret_key);
    put("pairing_code", c.pairing_code);
    put("me_jid", c.me_jid);
    put("platform", c.platform);
    puth("account", c.account);
    put("registered", c.registered ? "1" : "0");

    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return fail("creds: tidak bisa menulis " + tmp, ErrorCode::io);
        f << o.str();
        if (!f.good()) return fail("creds: gagal menulis " + tmp, ErrorCode::io);
    }
    ::chmod(tmp.c_str(), 0600);
    if (std::rename(tmp.c_str(), path.c_str()) != 0) return fail("creds: rename gagal", ErrorCode::io);
    return {};
}

Result<std::optional<Creds>> load_creds(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return std::optional<Creds>{};

    std::map<std::string, std::string> kv;
    std::string line;
    while (std::getline(f, line)) {
        if (line.empty() || line[0] == '#') continue;
        const auto eq = line.find('=');
        if (eq == std::string::npos) continue;
        kv[line.substr(0, eq)] = line.substr(eq + 1);
    }

    Creds c;
    struct Spec {
        const char* key;
        Bytes* dst;
        std::size_t size;
    };
    const Spec specs[] = {
        {"noise_priv", &c.noise_key.priv, 32},          {"noise_pub", &c.noise_key.pub, 32},
        {"identity_priv", &c.identity_key.priv, 32},    {"identity_pub", &c.identity_key.pub, 32},
        {"pairing_priv", &c.pairing_ephemeral.priv, 32}, {"pairing_pub", &c.pairing_ephemeral.pub, 32},
        {"spk_priv", &c.signed_prekey.priv, 32},        {"spk_pub", &c.signed_prekey.pub, 32},
        {"spk_sig", &c.signed_prekey_sig, 64},          {"adv_secret", &c.adv_secret_key, 32},
    };
    for (const auto& s : specs) {
        const auto it = kv.find(s.key);
        if (it == kv.end()) return fail(std::string("creds: field hilang: ") + s.key);
        auto b = from_hex(it->second);
        if (!b || b->size() != s.size) return fail(std::string("creds: field rusak: ") + s.key);
        *s.dst = std::move(*b);
    }

    auto spk_id = parse_u32(kv, "spk_id");
    auto reg_id = parse_u32(kv, "reg_id");
    if (!spk_id) return std::unexpected(spk_id.error());
    if (!reg_id) return std::unexpected(reg_id.error());
    c.signed_prekey_id = *spk_id;
    c.registration_id = *reg_id;

    auto get = [&](const char* key) -> std::string {
        const auto it = kv.find(key);
        return it == kv.end() ? std::string() : it->second;
    };
    c.pairing_code = get("pairing_code");
    c.me_jid = get("me_jid");
    c.platform = get("platform");
    if (const auto acc = get("account"); !acc.empty()) {
        auto b = from_hex(acc);
        if (!b) return fail("creds: field account rusak");
        c.account = std::move(*b);
    }
    c.registered = get("registered") == "1";
    return std::optional<Creds>{std::move(c)};
}

}  // namespace wa
