// Viana Studio© By Rasya
#include "wa/client.hpp"

#include <algorithm>
#include <charconv>
#include <chrono>
#include <functional>
#include <optional>
#include <thread>
#include <unordered_map>
#include <unordered_set>

#include "wa/binary.hpp"
#include "wa/noise.hpp"
#include "wa/outbound.hpp"
#include "wa/pairing.hpp"
#include "wa/signal.hpp"
#include "wa/ws.hpp"

namespace wa {
namespace {

using Clock = std::chrono::steady_clock;
using binary::make_node;
using binary::Node;
using binary::NodeList;

constexpr std::string_view kUserAgent =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

enum class Act { none, restart, done };

Node result_iq(std::string_view id) {
    return make_node("iq", {{"to", "s.whatsapp.net"}, {"type", "result"}, {"id", std::string(id)}});
}

// Ack standar untuk message / receipt / notification.
Node make_ack(const Node& n) {
    binary::Attrs a;
    a.emplace_back("id", std::string(n.attr("id").value_or("")));
    a.emplace_back("to", std::string(n.attr("from").value_or("")));
    a.emplace_back("class", n.tag);
    if (const auto p = n.attr("participant")) a.emplace_back("participant", std::string(*p));
    if (const auto r = n.attr("recipient")) a.emplace_back("recipient", std::string(*r));
    if (n.tag != "message") {
        if (const auto t = n.attr("type")) a.emplace_back("type", std::string(*t));
    }
    return make_node("ack", std::move(a));
}

Node make_delivery_receipt(const Node& n) {
    binary::Attrs a;
    a.emplace_back("id", std::string(n.attr("id").value_or("")));
    a.emplace_back("to", std::string(n.attr("from").value_or("")));
    if (const auto p = n.attr("participant")) a.emplace_back("participant", std::string(*p));
    if (n.attr("category") == "peer") a.emplace_back("type", "peer_msg");
    return make_node("receipt", std::move(a));
}

int elapsed_ms(Clock::time_point since) {
    return static_cast<int>(std::chrono::duration_cast<std::chrono::milliseconds>(Clock::now() - since).count());
}

}  // namespace

Client::Client(ClientConfig config) : cfg_(std::move(config)), store_(cfg_.store_path) {
    const Bytes r = crypto::random_bytes(4);
    id_a_ = (std::uint32_t(r[0]) << 8) | r[1];
    id_b_ = (std::uint32_t(r[2]) << 8) | r[3];
}

std::string Client::next_id() { return std::format("{}.{}-{}", id_a_, id_b_, ++counter_); }

void Client::enqueue_text(std::string to, std::string text) {
    std::lock_guard<std::mutex> lock(outbox_mutex_);
    outbox_.push_back(OutgoingText{std::move(to), std::move(text)});
}

bool Client::pop_outbox(OutgoingText& item) {
    std::lock_guard<std::mutex> lock(outbox_mutex_);
    if (outbox_.empty()) return false;
    item = std::move(outbox_.front());
    outbox_.pop_front();
    return true;
}

bool Client::outbox_empty() {
    std::lock_guard<std::mutex> lock(outbox_mutex_);
    return outbox_.empty();
}

Result<void> Client::run() {
    auto loaded = load_creds(cfg_.creds_path);
    if (!loaded) return std::unexpected(loaded.error());
    if (*loaded) {
        creds_ = std::move(**loaded);
    } else {
        auto fresh = generate_creds();
        if (!fresh) return std::unexpected(fresh.error());
        creds_ = std::move(*fresh);
    }

    if (!creds_.registered) {
        std::string phone;
        for (const char c : cfg_.phone)
            if (c >= '0' && c <= '9') phone += c;
        if (phone.size() < 8)
            return fail("--phone tidak valid, pakai nomor internasional asli tanpa +, mis. 6280000000000");
        creds_.me_jid = phone + "@s.whatsapp.net";
        creds_.pairing_code = cfg_.custom_code.empty() ? crypto::generate_pairing_code() : cfg_.custom_code;
        if (!crypto::is_valid_pairing_code(creds_.pairing_code))
            return fail("kode kustom harus 8 karakter dari 123456789ABCDEFGHJKLMNPQRSTVWXYZ");
    }
    if (auto r = save_creds(creds_, cfg_.creds_path); !r) return r;
    if (auto r = store_.load(); !r) return r;

    if (cfg_.lifetime_mode) {
        // Lifetime runtime: keep the existing session implementation intact,
        // but retry transient transport/session failures with capped backoff.
        unsigned attempt = 0;
        for (;;) {
            auto end = session();
            if (end) {
                if (*end == End::logged_in) return {};
                if (*end == End::closed) {
                    logf(LogLevel::warn, "server menutup koneksi sebelum login selesai");
                } else {
                    logf(LogLevel::warn, "sesi meminta restart");
                }
            } else {
                const Error& error = end.error();
                if (error.code == ErrorCode::protocol || error.code == ErrorCode::crypto) {
                    return std::unexpected(error); // kesalahan protokol/kunci jangan diulang tanpa akhir
                }
                logf(LogLevel::warn, "sesi berakhir: {}", error.message);
            }

            const unsigned shift = std::min(attempt, 5u);
            const unsigned delay_seconds = std::min(2u << shift, 60u);
            ++attempt;
            logf(LogLevel::info, "reconnect lifetime #{} dalam {} detik", attempt, delay_seconds);
            std::this_thread::sleep_for(std::chrono::seconds(delay_seconds));
        }
    }

    for (int attempt = 0; attempt <= cfg_.max_restarts; ++attempt) {
        auto end = session();
        if (!end) return std::unexpected(end.error());
        if (*end == End::logged_in) return {};
        if (*end == End::closed) return fail("server menutup koneksi", ErrorCode::closed);
        logf(LogLevel::info, "memulai ulang sesi ({}/{})", attempt + 1, cfg_.max_restarts);
    }
    return fail("terlalu banyak restart");
}

Result<Client::End> Client::session() {
    WsClient ws;
    WsOptions opt;
    opt.headers = {{"Origin", "https://web.whatsapp.com"}, {"User-Agent", std::string(kUserAgent)}};
    if (auto r = ws.connect(cfg_.url, opt); !r) return std::unexpected(r.error());

    auto eph = crypto::x25519_generate();
    if (!eph) return std::unexpected(eph.error());
    NoiseSession ns(*eph);

    // ---------------------------------------------------- Noise handshake ---
    {
        auto first = ns.frame(ns.client_hello());
        if (!first) return std::unexpected(first.error());
        if (auto r = ws.send_binary(*first); !r) return std::unexpected(r.error());
    }
    std::vector<Bytes> frames;
    while (frames.empty()) {
        auto msg = ws.receive(15000);
        if (!msg) return std::unexpected(msg.error());
        if (msg->op == WsOp::close) return fail("server menutup koneksi saat handshake", ErrorCode::closed);
        auto fr = ns.unframe(msg->data);
        if (!fr) return std::unexpected(fr.error());
        frames = std::move(*fr);
    }
    auto hello = NoiseSession::parse_server_hello(frames[0]);
    if (!hello) return std::unexpected(hello.error());
    auto key_enc = ns.process_server_hello(*hello, creds_.noise_key);
    if (!key_enc) return std::unexpected(key_enc.error());

    auto payload = creds_.registered ? build_login_payload(creds_, cfg_.version)
                                     : build_registration_payload(creds_, cfg_.version, cfg_.browser_os);
    if (!payload) return std::unexpected(payload.error());
    auto payload_enc = ns.encrypt(*payload);
    if (!payload_enc) return std::unexpected(payload_enc.error());
    auto finish_frame = ns.frame(NoiseSession::client_finish(*key_enc, *payload_enc));
    if (!finish_frame) return std::unexpected(finish_frame.error());
    if (auto r = ws.send_binary(*finish_frame); !r) return std::unexpected(r.error());
    ns.finish();
    logf(LogLevel::info, "handshake selesai, payload {} terkirim", creds_.registered ? "login" : "registrasi");

    // ------------------------------------------------------- event loop ---
    auto send = [&](const Node& n) -> Result<void> {
        auto fr = ns.frame(binary::encode(n));
        if (!fr) return std::unexpected(fr.error());
        return ws.send_binary(*fr);
    };

    sig::Cipher cipher(store_, creds_);
    using Pending = std::function<Result<void>(const Node&)>;
    std::unordered_map<std::string, Pending> pending;

    bool hello_sent = false;
    bool paired = false;
    const auto started = Clock::now();
    auto last_ping = started;

    auto send_hello = [&]() -> Result<void> {
        auto node = build_companion_hello(creds_, next_id(), cfg_.browser_os, cfg_.browser_name);
        if (!node) return std::unexpected(node.error());
        if (auto r = send(*node); !r) return r;
        hello_sent = true;
        logf(LogLevel::info, "companion_hello terkirim untuk {}", creds_.me_jid);
        if (cfg_.on_pairing_code) cfg_.on_pairing_code(creds_.pairing_code);
        return {};
    };

    // Tanya jumlah prekey di server; unggah bila kurang.
    auto sync_prekeys = [&]() -> Result<void> {
        const std::string id = next_id();
        pending[id] = [&](const Node& reply) -> Result<void> {
            std::uint32_t have = 0;
            if (const Node* count = reply.child("count")) {
                if (const auto v = count->attr("value")) std::from_chars(v->data(), v->data() + v->size(), have);
            }
            logf(LogLevel::info, "prekey di server: {} (lokal: {})", have, store_.prekey_count());
            if (have >= cfg_.prekey_min) return {};
            const auto keys = store_.generate_prekeys(cfg_.prekey_batch);
            if (auto r = store_.save(); !r) return r;  // simpan dulu sebelum diunggah
            const std::string up_id = next_id();
            pending[up_id] = [&, count = keys.size()](const Node& r2) -> Result<void> {
                if (r2.attr("type") == "result") logf(LogLevel::info, "{} prekey terunggah", count);
                else logf(LogLevel::warn, "unggah prekey ditolak:\n{}", binary::dump(r2));
                return {};
            };
            return send(sig::build_prekey_upload(creds_, keys, up_id));
        };
        return send(sig::build_prekey_count_query(id));
    };

    // Status pengiriman.
    std::optional<Act> deferred;                          // Act yang muncul saat menunggu balasan iq
    std::unordered_map<std::string, std::string> sent_ids;  // id pesan keluar -> tujuan
    std::unordered_set<std::string> awaiting;             // id yang belum di-ack server
    bool sent_any = false;
    auto last_send = started;

    // Pesan masuk: dekripsi -> callback -> ack -> receipt (atau retry bila gagal).
    auto handle_message = [&](const Node& n) -> Result<void> {
        const std::string id(n.attr("id").value_or(""));
        const std::string from(n.attr("from").value_or(""));
        const std::string sender_pn(n.attr("sender_pn").value_or(""));
        const std::string participant(n.attr("participant").value_or(""));
        const std::string category(n.attr("category").value_or(""));
        const bool is_group = from.ends_with("@g.us") || from.ends_with("@broadcast");
        const std::string author = is_group && !participant.empty() ? participant : from;
        std::uint64_t ts = 0;
        if (const auto t = n.attr("t")) std::from_chars(t->data(), t->data() + t->size(), ts);

        bool decrypted = false;
        bool failed = false;
        bool skipped_group = false;
        if (const auto* kids = n.children()) {
            for (const Node& c : *kids) {
                if (c.tag != "enc") continue;
                const std::string type(c.attr("type").value_or(""));
                if (type == "skmsg") {
                    skipped_group = true;
                    continue;
                }
                if (type != "pkmsg" && type != "msg") continue;

                const Bytes ct = c.payload();
                auto plain = cipher.decrypt(author, type, ct);
                std::string why;
                if (plain) {
                    auto unpadded = unpad_random_max16(*plain);
                    if (unpadded) {
                        IncomingMessage m = parse_message(*unpadded);
                        m.id = id;
                        m.from = from;
                        m.sender_pn = sender_pn;
                        m.author = author;
                        m.category = category;
                        m.timestamp = ts;
                        decrypted = true;
                        if (cfg_.on_message) cfg_.on_message(m);
                        continue;
                    }
                    why = unpadded.error().message;
                } else {
                    why = plain.error().message;
                }
                failed = true;
                logf(LogLevel::warn, "dekripsi {} dari {} gagal: {}", type, author, why);
            }
        }
        if (decrypted) {
            if (auto r = store_.save(); !r) logf(LogLevel::warn, "gagal menyimpan store: {}", r.error().message);
        }
        if (skipped_group && !decrypted)
            logf(LogLevel::info, "pesan grup (skmsg) dari {} dilewati: sender key belum didukung", author);

        if (failed) {
            int& count = retries_[id + ":" + participant];
            if (count < 5) {
                ++count;
                std::optional<sig::PreKey> fresh;
                if (count > 1) {
                    auto made = store_.generate_prekeys(1);
                    if (!made.empty()) {
                        fresh = made.front();
                        if (auto r = store_.save(); !r) logf(LogLevel::warn, "store: {}", r.error().message);
                    }
                }
                if (auto r = send(sig::build_retry_receipt(creds_, n, count, fresh ? &*fresh : nullptr)); !r) return r;
                logf(LogLevel::info, "retry receipt #{} dikirim untuk {}", count, id);
            }
        }
        if (auto r = send(make_ack(n)); !r) return r;
        if (decrypted) {
            if (auto r = send(make_delivery_receipt(n)); !r) return r;
        }
        return {};
    };

    auto handle = [&](const Node& n) -> Result<Act> {
        if (log_level() <= LogLevel::debug) logf(LogLevel::debug, "<- {}", binary::dump(n));
        const std::string_view id = n.attr("id").value_or("");
        const std::string_view type = n.attr("type").value_or("");

        if (n.tag == "message") {
            if (auto r = handle_message(n); !r) return std::unexpected(r.error());
            return Act::none;
        }

        if (n.tag == "ack") {
            if (n.attr("class") == "message") {
                const std::string ack_id(id);
                if (awaiting.erase(ack_id) != 0) {
                    const std::string& dest = sent_ids[ack_id];
                    if (const auto err = n.attr("error"))
                        logf(LogLevel::warn, "server menolak pesan {} ke {}: error {}", ack_id, dest, *err);
                    else
                        logf(LogLevel::info, "pesan {} diterima server (tujuan {})", ack_id, dest);
                }
            }
            return Act::none;
        }

        if (n.tag == "receipt") {
            if (sent_ids.contains(std::string(id))) {
                const std::string kind(type.empty() ? std::string_view("delivered") : type);
                logf(LogLevel::info, "receipt '{}' untuk pesan {} dari {}", kind, id, n.attr("from").value_or("?"));
            }
            if (auto r = send(make_ack(n)); !r) return std::unexpected(r.error());
            return Act::none;
        }

        if (n.tag == "iq") {
            if (type == "result" || type == "error") {
                if (const auto it = pending.find(std::string(id)); it != pending.end()) {
                    auto cb = std::move(it->second);
                    pending.erase(it);
                    if (auto r = cb(n); !r) return std::unexpected(r.error());
                    return Act::none;
                }
            }
            if (n.child("pair-device")) {
                if (auto r = send(result_iq(id)); !r) return std::unexpected(r.error());
                if (!hello_sent && !paired) {
                    if (auto r = send_hello(); !r) return std::unexpected(r.error());
                }
                return Act::none;
            }
            if (n.child("pair-success")) {
                auto reply = handle_pair_success(creds_, n);
                if (!reply) return std::unexpected(reply.error());
                if (auto r = save_creds(creds_, cfg_.creds_path); !r)
                    logf(LogLevel::warn, "gagal menyimpan creds: {}", r.error().message);
                if (auto r = send(*reply); !r) return std::unexpected(r.error());
                paired = true;
                logf(LogLevel::info, "PAIR-SUCCESS: perangkat tertaut sebagai {}", creds_.me_jid);
                return Act::none;
            }
            if (type == "get" && n.attr("xmlns") == "urn:xmpp:ping") {
                if (auto r = send(result_iq(id)); !r) return std::unexpected(r.error());
                return Act::none;
            }
            if (type == "error") return fail("server menolak permintaan:\n" + binary::dump(n), ErrorCode::protocol);
            return Act::none;
        }

        if (n.tag == "notification") {
            if (auto r = send(make_ack(n)); !r) return std::unexpected(r.error());
            if (type == "link_code_companion_reg") {
                auto fin = handle_link_code_notification(creds_, n, next_id());
                if (!fin) {
                    logf(LogLevel::warn, "notifikasi pairing diabaikan: {}", fin.error().message);
                    return Act::none;
                }
                if (auto r = save_creds(creds_, cfg_.creds_path); !r)
                    logf(LogLevel::warn, "gagal menyimpan creds: {}", r.error().message);
                if (auto r = send(*fin); !r) return std::unexpected(r.error());
                logf(LogLevel::info, "kode diterima HP, menyelesaikan penautan...");
            }
            return Act::none;
        }

        if (n.tag == "stream:error") {
            if (n.attr("code") == "515") return Act::restart;
            return fail("stream:error dari server:\n" + binary::dump(n), ErrorCode::protocol);
        }

        if (n.tag == "failure") {
            std::string why = "login ditolak:\n" + binary::dump(n);
            if (n.attr("reason") == "405") why += "versi WA Web kedaluwarsa: ambil ulang client_revision\n";
            return fail(why, ErrorCode::protocol);
        }

        if (n.tag == "success") {
            logf(LogLevel::info, "LOGIN OK sebagai {}", creds_.me_jid);
            if (!cfg_.stay_online) return Act::done;
            const Node active = make_node(
                "iq", {{"to", "s.whatsapp.net"}, {"xmlns", "passive"}, {"type", "set"}, {"id", next_id()}},
                NodeList{make_node("active")});
            if (auto r = send(active); !r) return std::unexpected(r.error());
            if (auto r = sync_prekeys(); !r) return std::unexpected(r.error());
            if (cfg_.on_ready) cfg_.on_ready(*this);
            return Act::none;
        }
        return Act::none;
    };

    // Kirim iq lalu tunggu balasan ber-id sama; node lain tetap diproses lewat handle().
    auto query = [&](const Node& iq, int timeout_ms) -> Result<Node> {
        const std::string qid(iq.attr("id").value_or(""));
        if (auto r = send(iq); !r) return std::unexpected(r.error());
        const auto qstart = Clock::now();
        for (;;) {
            const int remaining = timeout_ms - elapsed_ms(qstart);
            if (remaining <= 0) return fail("timeout menunggu balasan iq " + qid, ErrorCode::timeout);
            auto msg = ws.receive(std::min(remaining, 1000));
            if (!msg) {
                if (msg.error().code == ErrorCode::timeout) continue;
                return std::unexpected(msg.error());
            }
            if (msg->op == WsOp::close) return fail("koneksi ditutup saat menunggu iq", ErrorCode::closed);
            auto fr = ns.unframe(msg->data);
            if (!fr) return std::unexpected(fr.error());
            std::optional<Node> found;
            for (const Bytes& raw : *fr) {
                auto node = binary::decode(raw);
                if (!node) {
                    logf(LogLevel::warn, "node tidak terbaca: {}", node.error().message);
                    continue;
                }
                const auto t = node->attr("type");
                if (node->tag == "iq" && node->attr("id") == qid && (t == "result" || t == "error")) {
                    found = std::move(*node);
                    continue;
                }
                auto act = handle(*node);
                if (!act) return std::unexpected(act.error());
                if (*act != Act::none) deferred = *act;
            }
            if (found) return std::move(*found);
        }
    };

    // Alur kirim teks 1:1: usync perangkat -> prekey bundle (jika belum ada sesi) -> enkripsi -> stanza.
    auto send_text_now = [&](const std::string& to_input, const std::string& text) -> Result<std::string> {
        const std::string to = outbound::normalize_jid(to_input);
        const auto me = outbound::split_jid(creds_.me_jid);
        const auto dest = outbound::split_jid(to);
        if (to.empty() || !me || !dest) return fail("tujuan tidak valid: " + to_input, ErrorCode::protocol);
        const std::string me_bare = me->user + "@" + me->server;
        const std::string to_bare = dest->user + "@" + dest->server;
        const std::string my_device = outbound::format_jid(*me);

        std::vector<std::string> users{to_bare};
        if (me_bare != to_bare) users.push_back(me_bare);
        auto devs_reply = query(outbound::build_usync_devices_query(users, next_id(), next_id()), 15000);
        if (!devs_reply) return std::unexpected(devs_reply.error());
        if (devs_reply->attr("type") == "error")
            return fail("usync ditolak:\n" + binary::dump(*devs_reply), ErrorCode::protocol);
        auto devices = outbound::parse_usync_devices(*devs_reply);
        if (!devices) return std::unexpected(devices.error());
        std::erase(*devices, my_device);  // perangkat ini sendiri tidak perlu dienkripsi
        if (devices->empty()) return fail("tidak ada perangkat tujuan (nomor tidak terdaftar?)", ErrorCode::protocol);

        std::vector<std::string> mine;
        for (const auto& d : *devices) {
            const auto p = outbound::split_jid(d);
            if (p && p->user == me->user) mine.push_back(d);
        }

        std::vector<std::string> missing;
        for (const auto& d : *devices)
            if (!cipher.has_session(d)) missing.push_back(d);
        if (!missing.empty()) {
            auto keys_reply = query(outbound::build_key_fetch_query(missing, next_id()), 15000);
            if (!keys_reply) return std::unexpected(keys_reply.error());
            auto bundles = outbound::parse_key_bundles(*keys_reply);
            if (!bundles) return std::unexpected(bundles.error());
            for (const auto& b : *bundles) {
                if (auto r = cipher.init_outgoing(b.jid, b); !r)
                    logf(LogLevel::warn, "sesi {} gagal dibuat: {}", b.jid, r.error().message);
            }
        }

        const Bytes plain = outbound::build_text_message(text);
        const Bytes plain_me = outbound::build_device_sent_message(to, plain);
        std::vector<outbound::Participant> parts;
        for (const auto& d : *devices) {
            const bool is_mine = std::ranges::find(mine, d) != mine.end();
            const Bytes padded = outbound::pad_random_max16(is_mine ? plain_me : plain);
            auto enc = cipher.encrypt(d, padded);
            if (!enc) {
                logf(LogLevel::warn, "enkripsi untuk {} dilewati: {}", d, enc.error().message);
                continue;
            }
            parts.push_back(outbound::Participant{d, std::move(*enc)});
        }
        if (parts.empty()) return fail("tidak ada perangkat yang berhasil dienkripsi", ErrorCode::crypto);

        const std::string id = outbound::generate_message_id();
        if (auto r = send(outbound::build_message_stanza(to, id, "text", parts, creds_)); !r)
            return std::unexpected(r.error());
        if (auto r = store_.save(); !r) logf(LogLevel::warn, "gagal menyimpan store: {}", r.error().message);
        sent_ids[id] = to;
        awaiting.insert(id);
        sent_any = true;
        last_send = Clock::now();
        logf(LogLevel::info, "stanza pesan {} dikirim ke {} perangkat", id, parts.size());
        return id;
    };

    std::optional<Clock::time_point> idle_since;
    for (;;) {
        // 1) kirim antrean keluar
        OutgoingText item;
        while (pop_outbox(item)) {
            auto r = send_text_now(item.to, item.text);
            if (!r) {
                if (r.error().code == ErrorCode::closed || r.error().code == ErrorCode::io) return std::unexpected(r.error());
                logf(LogLevel::warn, "gagal mengirim ke {}: {}", item.to, r.error().message);
            }
        }

        // 2) Act yang tertunda dari query
        if (deferred) {
            const Act a = *deferred;
            deferred.reset();
            if (a == Act::restart) return End::restart;
            if (a == Act::done) return End::logged_in;
        }

        // 3) mode sekali-kirim: berhenti setelah semua ack + jeda singkat untuk receipt
        if (cfg_.exit_after_send && sent_any) {
            if (awaiting.empty() && outbox_empty()) {
                if (!idle_since) idle_since = Clock::now();
                if (Clock::now() - *idle_since > std::chrono::seconds(5)) return End::logged_in;
            } else {
                idle_since.reset();
                if (Clock::now() - last_send > std::chrono::seconds(25)) {
                    logf(LogLevel::warn, "tidak ada ack dari server dalam 25 detik, berhenti");
                    return End::logged_in;
                }
            }
        }

        auto msg = ws.receive(1000);
        if (!msg) {
            if (msg.error().code == ErrorCode::timeout) {
                const auto now = Clock::now();
                if (!creds_.registered && !hello_sent && !paired && now - started > std::chrono::seconds(5)) {
                    if (auto r = send_hello(); !r) return std::unexpected(r.error());
                }
                if (now - last_ping > std::chrono::seconds(20)) {
                    const Node ping = make_node(
                        "iq", {{"to", "s.whatsapp.net"}, {"type", "get"}, {"id", next_id()}, {"xmlns", "w:p"}},
                        NodeList{make_node("ping")});
                    if (auto r = send(ping); !r) return std::unexpected(r.error());
                    last_ping = now;
                }
                continue;
            }
            if (paired) return End::restart;
            return std::unexpected(msg.error());
        }
        if (msg->op == WsOp::close) return paired ? End::restart : End::closed;

        auto fr = ns.unframe(msg->data);
        if (!fr) return std::unexpected(fr.error());
        for (const Bytes& raw : *fr) {
            auto node = binary::decode(raw);
            if (!node) {
                logf(LogLevel::warn, "node tidak terbaca: {}", node.error().message);
                continue;
            }
            auto act = handle(*node);
            if (!act) return std::unexpected(act.error());
            if (*act == Act::restart) return End::restart;
            if (*act == Act::done) return End::logged_in;
        }
    }
}

}  // namespace wa
