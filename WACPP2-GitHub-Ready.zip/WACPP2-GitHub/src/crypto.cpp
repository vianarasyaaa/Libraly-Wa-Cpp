// Viana Studio© By Rasya
#include "wa/crypto.hpp"

#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>

#include <cstring>
#include <cstdlib>
#include <memory>

namespace wa::crypto {
namespace {

struct CipherCtxDeleter {
    void operator()(EVP_CIPHER_CTX* p) const noexcept { EVP_CIPHER_CTX_free(p); }
};
struct PkeyDeleter {
    void operator()(EVP_PKEY* p) const noexcept { EVP_PKEY_free(p); }
};
struct PkeyCtxDeleter {
    void operator()(EVP_PKEY_CTX* p) const noexcept { EVP_PKEY_CTX_free(p); }
};
using CipherCtx = std::unique_ptr<EVP_CIPHER_CTX, CipherCtxDeleter>;
using Pkey = std::unique_ptr<EVP_PKEY, PkeyDeleter>;
using PkeyCtx = std::unique_ptr<EVP_PKEY_CTX, PkeyCtxDeleter>;

Bytes digest(const EVP_MD* md, ByteView data) {
    Bytes out(EVP_MAX_MD_SIZE);
    unsigned int len = 0;
    EVP_Digest(data.data(), data.size(), out.data(), &len, md, nullptr);
    out.resize(len);
    return out;
}

}  // namespace

Bytes random_bytes(std::size_t n) {
    Bytes out(n);
    if (n != 0 && RAND_bytes(out.data(), static_cast<int>(n)) != 1) std::abort();  // entropi gagal = fatal
    return out;
}

void wipe(Bytes& b) {
    if (!b.empty()) OPENSSL_cleanse(b.data(), b.size());
}

Bytes sha1(ByteView data) { return digest(EVP_sha1(), data); }
Bytes sha256(ByteView data) { return digest(EVP_sha256(), data); }

Bytes hmac_sha256(ByteView key, ByteView data) {
    static const std::uint8_t kZero = 0;
    const std::uint8_t* kp = key.empty() ? &kZero : key.data();
    const std::uint8_t* dp = data.empty() ? &kZero : data.data();
    Bytes out(EVP_MAX_MD_SIZE);
    unsigned int len = 0;
    HMAC(EVP_sha256(), kp, static_cast<int>(key.size()), dp, data.size(), out.data(), &len);
    out.resize(len);
    return out;
}

Bytes hkdf_sha256(ByteView ikm, std::size_t length, ByteView salt, ByteView info) {
    if (length > 255 * 32) return {};
    const Bytes zero_salt(32, 0);
    const ByteView s = salt.empty() ? ByteView(zero_salt) : salt;
    const Bytes prk = hmac_sha256(s, ikm);

    Bytes out;
    out.reserve(length + 32);
    Bytes t;
    std::uint8_t counter = 1;
    while (out.size() < length) {
        Bytes msg;
        msg.reserve(t.size() + info.size() + 1);
        msg.insert(msg.end(), t.begin(), t.end());
        msg.insert(msg.end(), info.begin(), info.end());
        msg.push_back(counter++);
        t = hmac_sha256(prk, msg);
        out.insert(out.end(), t.begin(), t.end());
    }
    out.resize(length);
    return out;
}

Result<Bytes> pbkdf2_sha256(ByteView password, ByteView salt, std::uint32_t iterations, std::size_t length) {
    Bytes out(length);
    const int ok = PKCS5_PBKDF2_HMAC(reinterpret_cast<const char*>(password.data()), static_cast<int>(password.size()),
                                     salt.data(), static_cast<int>(salt.size()), static_cast<int>(iterations),
                                     EVP_sha256(), static_cast<int>(length), out.data());
    if (ok != 1) return fail("pbkdf2 gagal", ErrorCode::crypto);
    return out;
}

Result<Bytes> aes256_gcm_encrypt(ByteView key, ByteView iv, ByteView plaintext, ByteView aad) {
    if (key.size() != 32 || iv.size() != 12) return fail("aes-gcm: ukuran key/iv salah", ErrorCode::crypto);
    CipherCtx ctx(EVP_CIPHER_CTX_new());
    if (!ctx) return fail("aes-gcm: ctx gagal", ErrorCode::crypto);
    if (EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1 ||
        EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, 12, nullptr) != 1 ||
        EVP_EncryptInit_ex(ctx.get(), nullptr, nullptr, key.data(), iv.data()) != 1)
        return fail("aes-gcm: init gagal", ErrorCode::crypto);

    int len = 0;
    if (!aad.empty() && EVP_EncryptUpdate(ctx.get(), nullptr, &len, aad.data(), static_cast<int>(aad.size())) != 1)
        return fail("aes-gcm: aad gagal", ErrorCode::crypto);

    Bytes out(plaintext.size() + 16);
    int total = 0;
    if (!plaintext.empty()) {
        if (EVP_EncryptUpdate(ctx.get(), out.data(), &len, plaintext.data(), static_cast<int>(plaintext.size())) != 1)
            return fail("aes-gcm: enkripsi gagal", ErrorCode::crypto);
        total = len;
    }
    if (EVP_EncryptFinal_ex(ctx.get(), out.data() + total, &len) != 1)
        return fail("aes-gcm: final gagal", ErrorCode::crypto);
    total += len;
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_GET_TAG, 16, out.data() + total) != 1)
        return fail("aes-gcm: tag gagal", ErrorCode::crypto);
    out.resize(static_cast<std::size_t>(total) + 16);
    return out;
}

Result<Bytes> aes256_gcm_decrypt(ByteView key, ByteView iv, ByteView ciphertext, ByteView aad) {
    if (key.size() != 32 || iv.size() != 12) return fail("aes-gcm: ukuran key/iv salah", ErrorCode::crypto);
    if (ciphertext.size() < 16) return fail("aes-gcm: ciphertext terlalu pendek", ErrorCode::crypto);
    CipherCtx ctx(EVP_CIPHER_CTX_new());
    if (!ctx) return fail("aes-gcm: ctx gagal", ErrorCode::crypto);
    if (EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_gcm(), nullptr, nullptr, nullptr) != 1 ||
        EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_IVLEN, 12, nullptr) != 1 ||
        EVP_DecryptInit_ex(ctx.get(), nullptr, nullptr, key.data(), iv.data()) != 1)
        return fail("aes-gcm: init gagal", ErrorCode::crypto);

    const std::size_t body = ciphertext.size() - 16;
    int len = 0;
    if (!aad.empty() && EVP_DecryptUpdate(ctx.get(), nullptr, &len, aad.data(), static_cast<int>(aad.size())) != 1)
        return fail("aes-gcm: aad gagal", ErrorCode::crypto);

    Bytes out(body);
    int total = 0;
    if (body != 0) {
        if (EVP_DecryptUpdate(ctx.get(), out.data(), &len, ciphertext.data(), static_cast<int>(body)) != 1)
            return fail("aes-gcm: dekripsi gagal", ErrorCode::crypto);
        total = len;
    }
    std::uint8_t tag[16];
    std::memcpy(tag, ciphertext.data() + body, 16);
    if (EVP_CIPHER_CTX_ctrl(ctx.get(), EVP_CTRL_GCM_SET_TAG, 16, tag) != 1)
        return fail("aes-gcm: set tag gagal", ErrorCode::crypto);
    if (EVP_DecryptFinal_ex(ctx.get(), out.data() + total, &len) <= 0)
        return fail("aes-gcm: autentikasi gagal (tag tidak cocok)", ErrorCode::crypto);
    return out;
}

Result<Bytes> aes256_ctr(ByteView key, ByteView iv, ByteView data) {
    if (key.size() != 32 || iv.size() != 16) return fail("aes-ctr: ukuran key/iv salah", ErrorCode::crypto);
    CipherCtx ctx(EVP_CIPHER_CTX_new());
    if (!ctx || EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_ctr(), nullptr, key.data(), iv.data()) != 1)
        return fail("aes-ctr: init gagal", ErrorCode::crypto);
    Bytes out(data.size());
    int len = 0;
    int total = 0;
    if (!data.empty()) {
        if (EVP_EncryptUpdate(ctx.get(), out.data(), &len, data.data(), static_cast<int>(data.size())) != 1)
            return fail("aes-ctr: gagal", ErrorCode::crypto);
        total = len;
    }
    if (EVP_EncryptFinal_ex(ctx.get(), out.data() + total, &len) != 1)
        return fail("aes-ctr: final gagal", ErrorCode::crypto);
    return out;
}

Result<Bytes> aes256_cbc_encrypt(ByteView key, ByteView iv, ByteView plaintext) {
    if (key.size() != 32 || iv.size() != 16) return fail("aes-cbc: ukuran key/iv salah", ErrorCode::crypto);
    CipherCtx ctx(EVP_CIPHER_CTX_new());
    if (!ctx || EVP_EncryptInit_ex(ctx.get(), EVP_aes_256_cbc(), nullptr, key.data(), iv.data()) != 1)
        return fail("aes-cbc: init gagal", ErrorCode::crypto);
    Bytes out(plaintext.size() + 16);
    int len = 0;
    int total = 0;
    if (!plaintext.empty()) {
        if (EVP_EncryptUpdate(ctx.get(), out.data(), &len, plaintext.data(), static_cast<int>(plaintext.size())) != 1)
            return fail("aes-cbc: enkripsi gagal", ErrorCode::crypto);
        total = len;
    }
    if (EVP_EncryptFinal_ex(ctx.get(), out.data() + total, &len) != 1)
        return fail("aes-cbc: final gagal", ErrorCode::crypto);
    total += len;
    out.resize(static_cast<std::size_t>(total));
    return out;
}

Result<Bytes> aes256_cbc_decrypt(ByteView key, ByteView iv, ByteView ciphertext) {
    if (key.size() != 32 || iv.size() != 16) return fail("aes-cbc: ukuran key/iv salah", ErrorCode::crypto);
    if (ciphertext.empty() || ciphertext.size() % 16 != 0)
        return fail("aes-cbc: panjang ciphertext tidak valid", ErrorCode::crypto);
    CipherCtx ctx(EVP_CIPHER_CTX_new());
    if (!ctx || EVP_DecryptInit_ex(ctx.get(), EVP_aes_256_cbc(), nullptr, key.data(), iv.data()) != 1)
        return fail("aes-cbc: init gagal", ErrorCode::crypto);
    Bytes out(ciphertext.size() + 16);
    int len = 0;
    if (EVP_DecryptUpdate(ctx.get(), out.data(), &len, ciphertext.data(), static_cast<int>(ciphertext.size())) != 1)
        return fail("aes-cbc: dekripsi gagal", ErrorCode::crypto);
    int total = len;
    if (EVP_DecryptFinal_ex(ctx.get(), out.data() + total, &len) != 1)
        return fail("aes-cbc: padding tidak valid", ErrorCode::crypto);
    total += len;
    out.resize(static_cast<std::size_t>(total));
    return out;
}

Result<KeyPair> x25519_generate() {
    PkeyCtx ctx(EVP_PKEY_CTX_new_id(EVP_PKEY_X25519, nullptr));
    if (!ctx || EVP_PKEY_keygen_init(ctx.get()) != 1) return fail("x25519: init gagal", ErrorCode::crypto);
    EVP_PKEY* raw = nullptr;
    if (EVP_PKEY_keygen(ctx.get(), &raw) != 1) return fail("x25519: keygen gagal", ErrorCode::crypto);
    Pkey key(raw);
    KeyPair kp;
    kp.priv.resize(32);
    kp.pub.resize(32);
    std::size_t plen = 32;
    std::size_t ulen = 32;
    if (EVP_PKEY_get_raw_private_key(key.get(), kp.priv.data(), &plen) != 1 ||
        EVP_PKEY_get_raw_public_key(key.get(), kp.pub.data(), &ulen) != 1)
        return fail("x25519: ekspor kunci gagal", ErrorCode::crypto);
    return kp;
}

Result<Bytes> x25519_public(ByteView priv) {
    if (priv.size() != 32) return fail("x25519: private key harus 32 byte", ErrorCode::crypto);
    Pkey key(EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, nullptr, priv.data(), priv.size()));
    if (!key) return fail("x25519: private key tidak valid", ErrorCode::crypto);
    Bytes pub(32);
    std::size_t len = 32;
    if (EVP_PKEY_get_raw_public_key(key.get(), pub.data(), &len) != 1)
        return fail("x25519: ambil public gagal", ErrorCode::crypto);
    return pub;
}

Result<Bytes> x25519_shared(ByteView priv, ByteView pub) {
    if (pub.size() == 33 && pub[0] == 0x05) pub = pub.subspan(1);
    if (priv.size() != 32 || pub.size() != 32) return fail("x25519: ukuran kunci salah", ErrorCode::crypto);
    Pkey own(EVP_PKEY_new_raw_private_key(EVP_PKEY_X25519, nullptr, priv.data(), priv.size()));
    Pkey peer(EVP_PKEY_new_raw_public_key(EVP_PKEY_X25519, nullptr, pub.data(), pub.size()));
    if (!own || !peer) return fail("x25519: kunci tidak valid", ErrorCode::crypto);
    PkeyCtx ctx(EVP_PKEY_CTX_new(own.get(), nullptr));
    if (!ctx || EVP_PKEY_derive_init(ctx.get()) != 1 || EVP_PKEY_derive_set_peer(ctx.get(), peer.get()) != 1)
        return fail("x25519: derive init gagal", ErrorCode::crypto);
    Bytes out(32);
    std::size_t len = 32;
    if (EVP_PKEY_derive(ctx.get(), out.data(), &len) != 1 || len != 32)
        return fail("x25519: derive gagal", ErrorCode::crypto);
    return out;
}

// ---------------------------------------------------------- pairing code ---

std::string generate_pairing_code() {
    const Bytes r = random_bytes(5);
    std::uint64_t acc = 0;
    int bits = 0;
    std::string out;
    for (const std::uint8_t b : r) {
        acc = (acc << 8) | b;
        bits += 8;
        while (bits >= 5) {
            out += kCrockford[(acc >> (bits - 5)) & 31];
            bits -= 5;
        }
    }
    if (bits > 0) out += kCrockford[(acc << (5 - bits)) & 31];
    return out;
}

bool is_valid_pairing_code(std::string_view code) {
    if (code.size() != 8) return false;
    for (const char c : code)
        if (kCrockford.find(c) == std::string_view::npos) return false;
    return true;
}

Result<Bytes> derive_pairing_key(std::string_view code, ByteView salt) {
    return pbkdf2_sha256(view_of(code), salt, 2u << 16, 32);
}

Result<Bytes> wrap_companion_ephemeral(std::string_view code, ByteView ephemeral_pub) {
    if (!is_valid_pairing_code(code)) return fail("pairing code harus 8 karakter Crockford", ErrorCode::crypto);
    const Bytes salt = random_bytes(32);
    const Bytes iv = random_bytes(16);
    auto key = derive_pairing_key(code, salt);
    if (!key) return std::unexpected(key.error());
    auto ct = aes256_ctr(*key, iv, ephemeral_pub);
    if (!ct) return std::unexpected(ct.error());
    return concat({salt, iv, *ct});
}

}  // namespace wa::crypto
