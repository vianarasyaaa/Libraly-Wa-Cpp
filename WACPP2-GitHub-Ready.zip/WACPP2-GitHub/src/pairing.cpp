// Viana Studio© By Rasya
#include "wa/pairing.hpp"

#include <openssl/crypto.h>

#include <map>

#include "wa/xeddsa.hpp"

namespace wa {

using binary::make_node;
using binary::make_text_node;
using binary::Node;
using binary::NodeList;

namespace {

constexpr std::string_view kServer = "s.whatsapp.net";

Node iq(std::string_view type, std::string_view id, std::string_view xmlns, NodeList content) {
    binary::Attrs attrs{{"to", std::string(kServer)}, {"type", std::string(type)}, {"id", std::string(id)}};
    if (!xmlns.empty()) attrs.emplace_back("xmlns", std::string(xmlns));
    return make_node("iq", std::move(attrs), std::move(content));
}

std::string platform_id(std::string_view browser) {
    std::string b(browser);
    for (char& c : b) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if (b == "firefox") return "2";
    if (b == "ie") return "3";
    if (b == "opera") return "4";
    if (b == "safari") return "5";
    if (b == "edge") return "6";
    if (b == "desktop") return "7";
    return "1";  // chrome
}

Bytes child_bytes(const Node& parent, std::string_view tag) {
    const Node* c = parent.child(tag);
    return c ? c->payload() : Bytes{};
}

bool equal_ct(ByteView a, ByteView b) {
    return a.size() == b.size() && CRYPTO_memcmp(a.data(), b.data(), a.size()) == 0;
}

struct Parsed {
    std::map<std::uint32_t, Bytes> bytes;
    std::map<std::uint32_t, std::uint64_t> ints;
};

Result<Parsed> parse_fields(ByteView data) {
    Parsed out;
    pb::Reader r(data);
    for (;;) {
        auto f = r.next();
        if (!f) return std::unexpected(f.error());
        if (!*f) break;
        const auto& field = **f;
        if (field.wire == 2) out.bytes[field.number].assign(field.data.begin(), field.data.end());
        else if (field.wire == 0) out.ints[field.number] = field.value;
    }
    return out;
}

const Bytes* find_bytes(const Parsed& p, std::uint32_t n) {
    const auto it = p.bytes.find(n);
    return it == p.bytes.end() ? nullptr : &it->second;
}

}  // namespace

Result<Node> build_companion_hello(const Creds& creds, std::string_view iq_id, std::string_view os,
                                   std::string_view browser) {
    auto wrapped = crypto::wrap_companion_ephemeral(creds.pairing_code, creds.pairing_ephemeral.pub);
    if (!wrapped) return std::unexpected(wrapped.error());

    NodeList kids;
    kids.push_back(make_node("link_code_pairing_wrapped_companion_ephemeral_pub", {}, *wrapped));
    kids.push_back(make_node("companion_server_auth_key_pub", {}, creds.noise_key.pub));
    kids.push_back(make_text_node("companion_platform_id", {}, platform_id(browser)));
    kids.push_back(make_text_node("companion_platform_display", {}, std::format("{} ({})", browser, os)));
    kids.push_back(make_text_node("link_code_pairing_nonce", {}, "0"));

    Node reg = make_node(
        "link_code_companion_reg",
        {{"jid", creds.me_jid}, {"stage", "companion_hello"}, {"should_show_push_notification", "true"}},
        std::move(kids));
    return iq("set", iq_id, "md", NodeList{std::move(reg)});
}

Result<Node> handle_link_code_notification(Creds& creds, const Node& notification, std::string_view iq_id) {
    const Node* reg = notification.child("link_code_companion_reg");
    if (!reg) return fail("notifikasi tanpa link_code_companion_reg", ErrorCode::protocol);

    const Bytes ref = child_bytes(*reg, "link_code_pairing_ref");
    const Bytes primary_identity = child_bytes(*reg, "primary_identity_pub");
    const Bytes wrapped = child_bytes(*reg, "link_code_pairing_wrapped_primary_ephemeral_pub");
    if (ref.empty() || primary_identity.size() < 32 || wrapped.size() != 80)
        return fail("notifikasi pairing tidak lengkap (ref/identity/ephemeral)", ErrorCode::protocol);

    // 1) buka ephemeral primer: salt(32) || iv(16) || ct(32), kunci = PBKDF2(kode)
    const ByteView w(wrapped);
    auto key = crypto::derive_pairing_key(creds.pairing_code, w.subspan(0, 32));
    if (!key) return std::unexpected(key.error());
    auto primary_ephemeral = crypto::aes256_ctr(*key, w.subspan(32, 16), w.subspan(48, 32));
    if (!primary_ephemeral) return std::unexpected(primary_ephemeral.error());

    // 2) shared secret + bundel kunci terenkripsi
    auto companion_shared = crypto::x25519_shared(creds.pairing_ephemeral.priv, *primary_ephemeral);
    if (!companion_shared) return std::unexpected(companion_shared.error());

    const Bytes random = crypto::random_bytes(32);
    const Bytes link_salt = crypto::random_bytes(32);
    const Bytes expanded = crypto::hkdf_sha256(*companion_shared, 32, link_salt,
                                               view_of("link_code_pairing_key_bundle_encryption_key"));
    const Bytes bundle = concat({creds.identity_key.pub, primary_identity, random});
    const Bytes iv = crypto::random_bytes(12);
    auto encrypted = crypto::aes256_gcm_encrypt(expanded, iv, bundle);
    if (!encrypted) return std::unexpected(encrypted.error());
    const Bytes wrapped_bundle = concat({link_salt, iv, *encrypted});

    // 3) adv_secret
    auto identity_shared = crypto::x25519_shared(creds.identity_key.priv, primary_identity);
    if (!identity_shared) return std::unexpected(identity_shared.error());
    const Bytes identity_payload = concat({*companion_shared, *identity_shared, random});
    creds.adv_secret_key = crypto::hkdf_sha256(identity_payload, 32, {}, view_of("adv_secret"));

    Node reg_out = make_node("link_code_companion_reg", {{"jid", creds.me_jid}, {"stage", "companion_finish"}},
                             NodeList{make_node("link_code_pairing_wrapped_key_bundle", {}, wrapped_bundle),
                                      make_node("companion_identity_public", {}, creds.identity_key.pub),
                                      make_node("link_code_pairing_ref", {}, ref)});
    return iq("set", iq_id, "md", NodeList{std::move(reg_out)});
}

Result<Node> handle_pair_success(Creds& creds, const Node& stanza) {
    const Node* ps = stanza.child("pair-success");
    if (!ps) return fail("bukan stanza pair-success", ErrorCode::protocol);
    const Node* identity_node = ps->child("device-identity");
    const Node* device_node = ps->child("device");
    if (!identity_node || !device_node) return fail("pair-success tanpa device-identity/device", ErrorCode::protocol);
    const auto jid = device_node->attr("jid");
    if (!jid) return fail("pair-success tanpa jid perangkat", ErrorCode::protocol);

    // ADVSignedDeviceIdentityHMAC{details=1, hmac=2, accountType=3}
    auto outer = parse_fields(identity_node->payload());
    if (!outer) return std::unexpected(outer.error());
    const Bytes* details = find_bytes(*outer, 1);
    const Bytes* hmac = find_bytes(*outer, 2);
    if (!details || !hmac) return fail("device-identity tidak lengkap", ErrorCode::protocol);
    const bool hosted = outer->ints.count(3) != 0 && outer->ints[3] == 1;

    const Bytes hmac_prefix = hosted ? Bytes{6, 5} : Bytes{};
    const Bytes expected = crypto::hmac_sha256(creds.adv_secret_key, concat({hmac_prefix, *details}));
    if (!equal_ct(expected, *hmac)) return fail("HMAC identitas perangkat tidak cocok", ErrorCode::crypto);

    // ADVSignedDeviceIdentity{details=1, accountSignatureKey=2, accountSignature=3, deviceSignature=4}
    auto account = parse_fields(*details);
    if (!account) return std::unexpected(account.error());
    const Bytes* device_details = find_bytes(*account, 1);
    const Bytes* account_key = find_bytes(*account, 2);
    const Bytes* account_sig = find_bytes(*account, 3);
    if (!device_details || !account_key || !account_sig) return fail("ADV account tidak lengkap", ErrorCode::protocol);

    // ADVDeviceIdentity{rawId=1, timestamp=2, keyIndex=3, ...}
    auto dev = parse_fields(*device_details);
    if (!dev) return std::unexpected(dev.error());
    const std::uint64_t key_index = dev->ints.count(3) ? dev->ints[3] : 0;

    const Bytes account_prefix = hosted ? Bytes{6, 5} : Bytes{6, 0};
    const Bytes account_msg = concat({account_prefix, *device_details, creds.identity_key.pub});
    if (!crypto::xeddsa_verify(*account_key, account_msg, *account_sig))
        return fail("tanda tangan akun gagal diverifikasi", ErrorCode::crypto);

    const Bytes device_prefix = hosted ? Bytes{6, 6} : Bytes{6, 1};
    const Bytes device_msg = concat({device_prefix, *device_details, creds.identity_key.pub, *account_key});
    auto device_sig = crypto::xeddsa_sign(creds.identity_key.priv, device_msg);
    if (!device_sig) return std::unexpected(device_sig.error());

    auto encode_account = [&](bool include_key) {
        pb::Writer w;
        w.bytes(1, *device_details);
        if (include_key) w.bytes(2, *account_key);
        w.bytes(3, *account_sig).bytes(4, *device_sig);
        return w.take();
    };

    creds.me_jid = std::string(*jid);
    if (const Node* platform = ps->child("platform")) {
        if (const auto name = platform->attr("name")) creds.platform = std::string(*name);
    }
    creds.account = encode_account(true);
    creds.registered = true;

    const std::string id(stanza.attr("id").value_or(""));
    Node sign = make_node("pair-device-sign", {},
                          NodeList{make_node("device-identity", {{"key-index", std::to_string(key_index)}},
                                             encode_account(false))});
    return iq("result", id, "", NodeList{std::move(sign)});
}

}  // namespace wa
