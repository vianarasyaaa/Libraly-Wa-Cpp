// Viana Studio© By Rasya
#include "wa/outbound.hpp"

#include <algorithm>
#include <cctype>
#include <charconv>

namespace wa::outbound {

using binary::make_node;
using binary::Node;
using binary::NodeList;

namespace {

std::uint32_t be_uint(const Bytes& b) {
    std::uint32_t v = 0;
    for (const std::uint8_t x : b) v = (v << 8) | x;
    return v;
}

Bytes strip05(Bytes key) {
    if (key.size() == 33 && key[0] == 0x05) key.erase(key.begin());
    return key;
}

}  // namespace

std::optional<JidParts> split_jid(std::string_view jid) {
    const auto at = jid.find('@');
    if (at == std::string_view::npos) return std::nullopt;
    JidParts p;
    p.server = std::string(jid.substr(at + 1));
    std::string_view left = jid.substr(0, at);
    if (const auto colon = left.find(':'); colon != std::string_view::npos) {
        const auto dev = left.substr(colon + 1);
        std::from_chars(dev.data(), dev.data() + dev.size(), p.device);
        left = left.substr(0, colon);
    }
    if (const auto us = left.find('_'); us != std::string_view::npos) left = left.substr(0, us);
    p.user = std::string(left);
    if (p.user.empty() || p.server.empty()) return std::nullopt;
    return p;
}

std::string format_jid(const JidParts& p) {
    if (p.device != 0) return p.user + ":" + std::to_string(p.device) + "@" + p.server;
    return p.user + "@" + p.server;
}

std::string normalize_jid(std::string_view input) {
    if (input.find('@') != std::string_view::npos) return std::string(input);
    std::string digits;
    for (const char c : input)
        if (c >= '0' && c <= '9') digits += c;
    if (digits.size() < 8) return {};
    return digits + "@s.whatsapp.net";
}

std::string generate_message_id() {
    std::string hex = to_hex(crypto::random_bytes(18));
    std::ranges::transform(hex, hex.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    return "3EB0" + hex;
}

Bytes build_text_message(std::string_view text) {
    pb::Writer w;
    w.string(1, text);
    return w.take();
}

Bytes build_device_sent_message(std::string_view destination_jid, ByteView message) {
    pb::Writer inner;
    inner.string(1, destination_jid).bytes(2, message);
    pb::Writer w;
    w.message(31, inner);
    return w.take();
}

Bytes pad_random_max16(ByteView data) {
    std::uint8_t pad = crypto::random_bytes(1)[0] & 0x0F;
    if (pad == 0) pad = 0x0F;
    Bytes out(data.begin(), data.end());
    out.insert(out.end(), static_cast<std::size_t>(pad), pad);
    return out;
}

// ------------------------------------------------------------------ usync ---

Node build_usync_devices_query(const std::vector<std::string>& user_jids, std::string_view iq_id,
                               std::string_view sid) {
    NodeList users;
    for (const auto& j : user_jids) users.push_back(make_node("user", {{"jid", j}}));
    Node usync = make_node("usync",
                           {{"context", "message"},
                            {"mode", "query"},
                            {"sid", std::string(sid)},
                            {"last", "true"},
                            {"index", "0"}},
                           NodeList{make_node("query", {}, NodeList{make_node("devices", {{"version", "2"}})}),
                                    make_node("list", {}, std::move(users))});
    return make_node("iq",
                     {{"to", "s.whatsapp.net"}, {"type", "get"}, {"xmlns", "usync"}, {"id", std::string(iq_id)}},
                     NodeList{std::move(usync)});
}

Result<std::vector<std::string>> parse_usync_devices(const Node& iq) {
    const Node* usync = iq.child("usync");
    const Node* list = usync ? usync->child("list") : nullptr;
    if (!list || !list->children()) return fail("respons usync tanpa daftar pengguna", ErrorCode::protocol);

    std::vector<std::string> result;
    for (const Node& user : *list->children()) {
        if (user.tag != "user") continue;
        const auto jid = user.attr("jid");
        if (!jid) continue;
        const auto base = split_jid(*jid);
        if (!base) continue;
        const Node* devices = user.child("devices");
        const Node* dl = devices ? devices->child("device-list") : nullptr;
        if (!dl || !dl->children()) continue;
        for (const Node& d : *dl->children()) {
            if (d.tag != "device") continue;
            std::uint32_t id = 0;
            if (const auto v = d.attr("id")) std::from_chars(v->data(), v->data() + v->size(), id);
            if (id != 0 && !d.attr("key-index")) continue;
            JidParts p = *base;
            p.device = id;
            result.push_back(format_jid(p));
        }
    }
    return result;
}

// --------------------------------------------------------- bundel prekey ---

Node build_key_fetch_query(const std::vector<std::string>& jids, std::string_view iq_id) {
    NodeList users;
    for (const auto& j : jids) users.push_back(make_node("user", {{"jid", j}}));
    return make_node("iq",
                     {{"xmlns", "encrypt"}, {"type", "get"}, {"to", "s.whatsapp.net"}, {"id", std::string(iq_id)}},
                     NodeList{make_node("key", {}, std::move(users))});
}

Result<std::vector<sig::PreKeyBundle>> parse_key_bundles(const Node& iq) {
    const Node* list = iq.child("list");
    if (!list || !list->children()) return fail("respons prekey tanpa daftar", ErrorCode::protocol);

    std::vector<sig::PreKeyBundle> result;
    for (const Node& u : *list->children()) {
        if (u.tag != "user") continue;
        const auto jid = u.attr("jid");
        if (!jid) continue;
        if (u.child("error")) {
            logf(LogLevel::warn, "server menolak memberi prekey untuk {}", *jid);
            continue;
        }
        const Node* reg = u.child("registration");
        const Node* ident = u.child("identity");
        const Node* skey = u.child("skey");
        if (!reg || !ident || !skey) {
            logf(LogLevel::warn, "bundel prekey {} tidak lengkap", *jid);
            continue;
        }
        const Node* sid = skey->child("id");
        const Node* sval = skey->child("value");
        const Node* ssig = skey->child("signature");
        if (!sid || !sval || !ssig) continue;

        sig::PreKeyBundle b;
        b.jid = std::string(*jid);
        b.registration_id = be_uint(reg->payload());
        b.identity = strip05(ident->payload());
        b.signed_id = be_uint(sid->payload());
        b.signed_pub = strip05(sval->payload());
        b.signed_sig = ssig->payload();
        if (const Node* key = u.child("key")) {
            const Node* kid = key->child("id");
            const Node* kval = key->child("value");
            if (kid && kval) {
                b.has_prekey = true;
                b.prekey_id = be_uint(kid->payload());
                b.prekey_pub = strip05(kval->payload());
            }
        }
        result.push_back(std::move(b));
    }
    return result;
}

// ----------------------------------------------------------------- stanza ---

Node build_message_stanza(std::string_view to, std::string_view id, std::string_view type,
                          const std::vector<Participant>& participants, const Creds& creds) {
    NodeList parts;
    bool has_prekey_message = false;
    for (const auto& p : participants) {
        if (p.enc.prekey_message) has_prekey_message = true;
        const std::string enc_type = p.enc.prekey_message ? "pkmsg" : "msg";
        parts.push_back(make_node("to", {{"jid", p.jid}},
                                  NodeList{make_node("enc", {{"v", "2"}, {"type", enc_type}}, p.enc.data)}));
    }
    NodeList content;
    content.push_back(make_node("participants", {}, std::move(parts)));
    if (has_prekey_message) content.push_back(make_node("device-identity", {}, creds.account));
    return make_node("message", {{"id", std::string(id)}, {"type", std::string(type)}, {"to", std::string(to)}},
                     std::move(content));
}

}  // namespace wa::outbound
