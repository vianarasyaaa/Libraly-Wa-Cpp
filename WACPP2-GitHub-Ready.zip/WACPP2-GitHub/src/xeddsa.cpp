// Viana Studio© By Rasya
#include "wa/xeddsa.hpp"

#include <openssl/bn.h>
#include <sodium.h>

#include <cstring>
#include <memory>

#include "wa/crypto.hpp"

namespace wa::crypto {
namespace {

bool sodium_ready() {
    static const bool ok = sodium_init() >= 0;
    return ok;
}

struct BnDeleter {
    void operator()(BIGNUM* b) const noexcept { BN_free(b); }
};
struct BnCtxDeleter {
    void operator()(BN_CTX* c) const noexcept { BN_CTX_free(c); }
};
using Bn = std::unique_ptr<BIGNUM, BnDeleter>;
using BnCtx = std::unique_ptr<BN_CTX, BnCtxDeleter>;

}  // namespace

Result<Bytes> xeddsa_sign(ByteView priv, ByteView msg) {
    if (priv.size() != 32) return fail("xeddsa: private key harus 32 byte", ErrorCode::crypto);
    if (!sodium_ready()) return fail("xeddsa: libsodium gagal init", ErrorCode::crypto);

    std::uint8_t a[32];
    std::memcpy(a, priv.data(), 32);
    a[0] &= 248;
    a[31] &= 127;
    a[31] |= 64;

    std::uint8_t A[32];
    if (crypto_scalarmult_ed25519_base_noclamp(A, a) != 0) return fail("xeddsa: kunci publik gagal", ErrorCode::crypto);
    const std::uint8_t sign_bit = A[31] & 0x80;

    // r = H(0xFE 0xFF*31 || a || M || Z) mod L
    Bytes buf;
    buf.reserve(32 + 32 + msg.size() + 64);
    buf.push_back(0xFE);
    buf.insert(buf.end(), std::size_t{31}, std::uint8_t{0xFF});
    buf.insert(buf.end(), a, a + 32);
    buf.insert(buf.end(), msg.begin(), msg.end());
    const Bytes z = random_bytes(64);
    buf.insert(buf.end(), z.begin(), z.end());
    std::uint8_t h[64];
    crypto_hash_sha512(h, buf.data(), buf.size());
    std::uint8_t r[32];
    crypto_core_ed25519_scalar_reduce(r, h);

    std::uint8_t R[32];
    if (crypto_scalarmult_ed25519_base_noclamp(R, r) != 0) return fail("xeddsa: nonce gagal", ErrorCode::crypto);

    // k = H(R || A || M) mod L
    Bytes hin;
    hin.reserve(64 + msg.size());
    hin.insert(hin.end(), R, R + 32);
    hin.insert(hin.end(), A, A + 32);
    hin.insert(hin.end(), msg.begin(), msg.end());
    crypto_hash_sha512(h, hin.data(), hin.size());
    std::uint8_t k[32];
    crypto_core_ed25519_scalar_reduce(k, h);

    // s = k*a + r mod L
    std::uint8_t a64[64] = {0};
    std::memcpy(a64, a, 32);
    std::uint8_t a_red[32];
    crypto_core_ed25519_scalar_reduce(a_red, a64);
    std::uint8_t ka[32];
    std::uint8_t s[32];
    crypto_core_ed25519_scalar_mul(ka, k, a_red);
    crypto_core_ed25519_scalar_add(s, ka, r);

    Bytes sig(64);
    std::memcpy(sig.data(), R, 32);
    std::memcpy(sig.data() + 32, s, 32);
    sig[63] &= 0x7F;
    sig[63] |= sign_bit;

    sodium_memzero(a, sizeof a);
    sodium_memzero(a64, sizeof a64);
    sodium_memzero(a_red, sizeof a_red);
    sodium_memzero(r, sizeof r);
    return sig;
}

bool xeddsa_verify(ByteView pub, ByteView msg, ByteView sig) {
    if (pub.size() == 33 && pub[0] == 0x05) pub = pub.subspan(1);
    if (pub.size() != 32 || sig.size() != 64 || !sodium_ready()) return false;

    // u (Montgomery) -> y (Edwards): y = (u - 1) / (u + 1) mod p
    std::uint8_t ub[32];
    std::memcpy(ub, pub.data(), 32);
    ub[31] &= 0x7F;

    BnCtx ctx(BN_CTX_new());
    Bn u(BN_lebin2bn(ub, 32, nullptr));
    Bn p(BN_new());
    Bn one(BN_new());
    Bn num(BN_new());
    Bn den(BN_new());
    Bn y(BN_new());
    if (!ctx || !u || !p || !one || !num || !den || !y) return false;
    BN_set_bit(p.get(), 255);
    BN_sub_word(p.get(), 19);
    BN_one(one.get());
    if (!BN_mod_sub(num.get(), u.get(), one.get(), p.get(), ctx.get()) ||
        !BN_mod_add(den.get(), u.get(), one.get(), p.get(), ctx.get()) || BN_is_zero(den.get()))
        return false;
    Bn inv(BN_mod_inverse(nullptr, den.get(), p.get(), ctx.get()));
    if (!inv || !BN_mod_mul(y.get(), num.get(), inv.get(), p.get(), ctx.get())) return false;

    std::uint8_t ed[32];
    if (BN_bn2lebinpad(y.get(), ed, 32) != 32) return false;
    ed[31] = static_cast<std::uint8_t>((ed[31] & 0x7F) | (sig[63] & 0x80));

    std::uint8_t sg[64];
    std::memcpy(sg, sig.data(), 64);
    sg[63] &= 0x7F;
    return crypto_sign_ed25519_verify_detached(sg, msg.data(), msg.size(), ed) == 0;
}

}  // namespace wa::crypto
