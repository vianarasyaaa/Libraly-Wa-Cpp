<div align="center">
  <img src="assets/wacpp-icon.png" alt="Icon WACPP2" width="190">
  <br>
  <img src="assets/wacpp-banner.png" alt="WACPP2 — WhatsApp C++ Library by Viana Studio" width="92%">
  <h1>🌈 WACPP2 — WhatsApp C++ Library</h1>
  <p><b>Viana Studio© By Rasya</b></p>
  <p><i>Library C++ buat yang pengin ngulik koneksi WhatsApp dari sisi native C++.</i></p>
  <p>
    <img src="https://img.shields.io/badge/C%2B%2B-2c-blue?style=for-the-badge&logo=c%2B%2B&logoColor=white" alt="C++">
    <img src="https://img.shields.io/badge/Platform-Termux%20%7C%20Linux-22c55e?style=for-the-badge&logo=linux&logoColor=white" alt="Platforms">
    <img src="https://img.shields.io/badge/Status-Early%20Stage-ff9f43?style=for-the-badge" alt="Early stage">
    <img src="https://img.shields.io/badge/Brand-Viana%20Studio%E2%84%A2-ec4899?style=for-the-badge" alt="Viana Studio">
  </p>
</div>

---

## 👋 Woi, welcome to WACPP2!

Kenalin, **WACPP2** adalah library berbasis **C++** buat membangun aplikasi yang perlu berkomunikasi lewat koneksi WhatsApp Web. Fokusnya ada di fondasi komunikasi: koneksi WebSocket, handshake, pairing, pengolahan paket, enkripsi sesi, sampai proses kirim dan terima pesan teks.

Jadi gini: ini **library**, bukan jasa bot WhatsApp, bukan bot siap pakai yang tinggal scan terus langsung jadi, dan bukan layanan hosting bot. Source ini disediakan sebagai fondasi supaya developer bisa mempelajari, mengintegrasikan, dan mengembangkan aplikasinya sendiri.

> 🌈 **Small library, big possibilities.** Tapi jangan salah paham dulu, project ini masih tahap awal. Kita klaim sesuai kondisi sekarang: masih awal, masih ada batasan, dan masih terus berkembang.

## ✨ Yang sudah ada di source ini

| Bagian | Yang dikerjakan | Status |
|---|---|---|
| 🌐 Transport | WebSocket client dan komunikasi ke endpoint WhatsApp Web | Ada |
| 🤝 Handshake | Noise handshake untuk membangun sesi koneksi | Ada |
| 🔗 Pairing | Alur pairing perangkat dan kode pairing | Ada |
| 🔐 Crypto | Primitive kriptografi, key material, dan enkripsi pesan | Ada |
| 🔑 Session | Pengelolaan prekey dan session berbasis Signal/Double Ratchet | Ada |
| 📦 WABinary | Encoding dan decoding node/protokol biner | Ada |
| 🧩 Protobuf | Pembacaan struktur pesan protobuf | Ada |
| 💬 Pesan teks | Parsing pesan masuk dan pengiriman teks | Ada |
| 📬 Delivery | Penanganan ACK dan receipt pesan | Ada |
| 📱 Multi-device | Query perangkat tujuan dan pengiriman terenkripsi ke perangkat | Ada |
| 🔁 Runtime | Mode berjalan terus dan percobaan reconnect dengan jeda bertahap | Ada |
| 🧪 Self-test | Tes sejumlah fungsi crypto, codec, JID, dan Signal session | Ada |

### 🧠 Bagian teknisnya ngapain aja?

- **WebSocket layer** — membuka koneksi dan menangani frame WebSocket.
- **Noise layer** — menangani framing/handshake Noise yang dipakai jalur koneksi.
- **Pairing & credentials** — menyiapkan data perangkat dan menyimpan kredensial lokal.
- **Crypto layer** — menyediakan fungsi hash, HKDF, PBKDF2, X25519, AES-GCM, XEdDSA, dan helper kriptografi lain yang dipakai source.
- **Signal layer** — mengelola prekey, sesi, ratchet, enkripsi, dan dekripsi pesan.
- **Binary layer** — membaca dan menulis node WABinary beserta tabel token.
- **Message layer** — membaca struktur protobuf pesan dan mengidentifikasi tipe konten yang dikenali parser.
- **Outbound layer** — normalisasi JID, query daftar perangkat, pengambilan key bundle, pembuatan pesan teks, dan stanza pengiriman.
- **Client layer** — menggabungkan koneksi, event loop, callback pesan, antrian kirim, ACK, dan reconnect.

## 🚦 Status project — real talk

**WACPP2 masih tahap awal (early stage).** Jangan anggap semua fitur WhatsApp sudah tersedia atau semua kondisi jaringan sudah dites. Versi yang dibagikan ini adalah snapshot source yang berhasil dibangun dan diuji pada lingkungan pengembang.

| Fitur / area | Kondisi saat ini |
|---|---|
| Koneksi, login perangkat tertaut, dan pairing | Sudah ada pada jalur yang diuji |
| Terima pesan teks | Sudah diuji |
| Kirim pesan teks | Sudah diuji |
| `cpp menu`, `cpp ping`, `cpp status`, `cpp about` pada demo runtime | Ada sebagai contoh command sederhana |
| Reconnect runtime | Sudah diuji pada sesi pengembang |
| Pesan grup | Belum menjadi fitur lengkap; beberapa jalur group sender-key belum didukung |
| Upload/download media | Belum tersedia sebagai API media yang lengkap |
| Tombol interaktif / UI custom WhatsApp | Bukan bagian dari implementasi ini |
| Stabilitas di semua versi WhatsApp dan semua perangkat | Belum dijamin |

**Catatan penting:** parser mengenali beberapa tipe pesan tambahan (misalnya image, video, audio, dokumen, lokasi, dan reaction), tetapi itu **tidak berarti** fitur download/upload media atau seluruh pemrosesan tipe tersebut sudah lengkap. Pengiriman outbound yang disediakan saat ini berfokus pada teks.

## 🏗️ Struktur repository

```text
WACPP2/
├── assets/
│   ├── wacpp-banner.png       # Banner brand pelangi
│   └── wacpp-icon.png         # Icon WACPP2
├── include/wa/
│   ├── binary.hpp             # WABinary node/codec
│   ├── client.hpp             # Client dan konfigurasi callback
│   ├── common.hpp             # Tipe dasar, Result, helper bytes
│   ├── creds.hpp              # Struktur credentials
│   ├── crypto.hpp             # API cryptography
│   ├── message.hpp            # Struktur IncomingMessage
│   ├── noise.hpp              # Noise transport/session
│   ├── outbound.hpp           # JID, prekey query, stanza pesan
│   ├── pairing.hpp            # Alur pairing
│   ├── payload.hpp            # Payload login/register dan versi
│   ├── signal.hpp             # Store, prekey, cipher/session
│   ├── tokens.inc             # Tabel token WABinary
│   └── ws.hpp                 # WebSocket client
├── src/
│   ├── binary.cpp
│   ├── client.cpp
│   ├── creds.cpp
│   ├── crypto.cpp
│   ├── main.cpp               # CLI/demo dan self-test
│   ├── message.cpp
│   ├── noise.cpp
│   ├── outbound.cpp
│   ├── pairing.cpp
│   ├── payload.cpp
│   ├── signal.cpp
│   ├── signal_send.cpp
│   ├── ws.cpp
│   └── xeddsa.cpp
├── tools/
│   └── gen_tokens.py          # Generator tabel token
├── .gitignore
├── Makefile
└── README.md
```

`creds.txt`, `signal.txt`, file build, dan file backup **sengaja tidak disertakan**. File tersebut bukan bahan publik repository.

## 📲 Build di Termux (Android)

Gas, kalau build dari Android/Termux:

### 1. Siapkan paket

```bash
pkg update && pkg upgrade
pkg install clang make openssl libsodium zlib python
```

### 2. Clone repository

```bash
git clone https://github.com/USERNAME/WACPP2.git
cd WACPP2
```

Ganti `USERNAME` dengan username GitHub pemilik repo setelah repository dibuat.

### 3. Build source

```bash
make -j2
```

Kalau sukses, Makefile akan membuat:

```text
build/libwacpp.a   # Static library
build/wacpp2       # CLI/demo dan self-test
```

### 4. Jalankan self-test

```bash
./build/wacpp2 selftest
```

Self-test memeriksa beberapa primitive crypto, roundtrip encoding, JID, padding pesan, dan pertukaran session Signal. Tes lokal ini bukan sertifikasi keamanan dan bukan jaminan seluruh protokol kompatibel selamanya.

## 🐧 Build di Linux

Contoh dependency untuk distro berbasis Debian/Ubuntu:

```bash
sudo apt update
sudo apt install clang make libssl-dev libsodium-dev zlib1g-dev python3
git clone https://github.com/USERNAME/WACPP2.git
cd WACPP2
make -j2
./build/wacpp2 selftest
```

Build yang paling sering diuji pada snapshot ini adalah **Clang di Termux**. Platform lain perlu diuji sendiri, terutama karena Makefile memakai flag C++2c yang membutuhkan compiler cukup baru.

## 🧪 Mode CLI / demo runtime

Repository menyediakan executable kecil untuk menguji jalur library. Ini bukan produk bot siap pakai atau layanan bot.

> ⚠️ Untuk pairing pertama, gunakan akun/perangkat milik sendiri. Jangan pernah memasukkan nomor orang lain tanpa izin.

Contoh pola pairing (ganti placeholder dan versi dengan nilai yang sesuai dari client WhatsApp Web yang sedang dipakai):

```bash
./build/wacpp2 pair --phone 628xxxxxxxxxx --version 2.3000.REVISION
```

Untuk menjalankan mode runtime yang tetap hidup dan mencoba reconnect:

```bash
./build/wacpp2 cpp start --version 2.3000.REVISION
```

Perintah demo yang dikenali lewat chat pribadi pada runtime saat ini:

```text
cpp menu
cpp ping
cpp status
cpp about
```

Prefix tersebut adalah **contoh command pada executable demo**, bukan API utama library. Bagian inti yang bisa diintegrasikan ada di header `include/wa/`.

## 🧩 Pakai dari project C++ kamu

Header publik utamanya ada di `include/wa/`. Contoh sederhana untuk mengatur client dan callback pesan:

```cpp
#include "wa/client.hpp"
#include "wa/payload.hpp"

#include <iostream>
#include <utility>

int main() {
    wa::ClientConfig config;

    auto version = wa::parse_version("2.3000.REVISION");
    if (!version) {
        std::cerr << version.error().message << '\n';
        return 1;
    }

    config.version = *version;
    config.phone = "628xxxxxxxxxx"; // hanya untuk pairing pertama
    config.on_pairing_code = [](std::string_view code) {
        std::cout << "Pairing code: " << code << '\n';
    };
    config.on_message = [](const wa::IncomingMessage& message) {
        std::cout << "From: " << message.author << '\n';
        std::cout << "Type: " << message.kind << '\n';
        std::cout << "Text: " << message.text << '\n';
    };

    wa::Client client(std::move(config));
    auto result = client.run();
    if (!result) {
        std::cerr << "Client error: " << result.error().message << '\n';
        return 1;
    }
    return 0;
}
```

Contoh di atas menunjukkan konfigurasi dasar dan callback. Untuk project nyata, kamu perlu mengatur lokasi file credentials/store, alur pairing, lifecycle aplikasi, serta cara menghubungkan target static library dan dependency melalui build system project-mu.

### API yang kelihatan dari header

| API | Kegunaan |
|---|---|
| `wa::ClientConfig` | URL, versi, path credentials/store, pairing, dan callback |
| `wa::Client` | Menjalankan client dan mengantrekan pesan teks |
| `Client::run()` | Menjalankan alur pairing/login dan loop client |
| `Client::enqueue_text(to, text)` | Memasukkan pesan teks ke antrean pengiriman |
| `wa::IncomingMessage` | Data pesan masuk: ID, from, sender PN, author, category, timestamp, kind, text |
| `wa::parse_version()` | Mengurai versi WhatsApp Web tiga bagian |
| `wa::outbound::normalize_jid()` | Menormalkan alamat JID |
| `wa::parse_message()` | Mengurai protobuf pesan masuk |

Nama dan detail API dapat berubah selama project masih early stage. Cek header langsung sebelum mengintegrasikan ke aplikasi yang lebih besar.

## 🔐 Security & privasi — jangan skip!

Ini bagian penting banget:

- `creds.txt` menyimpan material identitas/kredensial perangkat.
- `signal.txt` menyimpan data session kriptografi dan state ratchet.
- **Jangan upload** kedua file itu ke GitHub, Discord, grup, atau tempat publik lain.
- Jangan share pairing code, private key, session dump, atau log debug mentah.
- `.gitignore` sudah disiapkan untuk mengabaikan file credentials, store, build, log, backup, dan file sementara.
- Kalau kredensial pernah terlanjur dipublikasikan, anggap sudah bocor dan unlink perangkat terkait dari WhatsApp.

Di repository publik ini, data sesi pengembang sudah dikeluarkan. Saat kamu menjalankan program sendiri, credentials/store lokal akan dibuat di perangkatmu sesuai konfigurasi.

## 🧱 Batasan dan disclaimer

- WACPP2 bukan aplikasi resmi WhatsApp dan tidak berafiliasi, disponsori, atau didukung oleh WhatsApp/Meta.
- Implementasi berkomunikasi dengan protokol WhatsApp Web yang dapat berubah sewaktu-waktu. Update sisi WhatsApp bisa membuat koneksi atau fitur tertentu berhenti bekerja.
- Tidak ada jaminan uptime, dukungan produksi, atau kompatibilitas lintas semua versi.
- Gunakan hanya untuk akun dan perangkat yang kamu berhak kelola. Patuhi ketentuan layanan dan hukum yang berlaku.
- Jangan gunakan library ini untuk spam, penipuan, mengambil alih akun, atau mengganggu pengguna lain.

## 🌱 Status pengembangan

Project ini dikerjakan **sendirian oleh satu orang**. Waktu pengerjaan sampai snapshot ini kurang lebih **1 minggu 3 hari**. Bukan tim besar, bukan studio raksasa—semua dikerjakan satu orang, pelan-pelan, sambil ngetes dan benerin bug yang ketemu.

Sekarang posisinya masih **tahap awal**. Jadi kalau nemu bug, jangan langsung ngegas dulu 😭. Catat log yang sudah disensor, jelaskan langkah reproduksi, lalu kirim feedback lewat kontak di bawah.

## 📮 Kontak

**Rasya — Viana Studio© By Rasya**

- ✉️ Email: **[rasyaatdia@gmail.com](mailto:rasyaatdia@gmail.com)**
- 💬 WhatsApp: **[+62 857-3807-4528](https://wa.me/6285738074528)**

## 📜 Lisensi

Belum ada file lisensi yang ditetapkan pada snapshot ini. Jangan mengasumsikan bahwa source publik otomatis memberi izin penggunaan ulang, distribusi ulang, atau penggunaan komersial. Lisensi perlu ditentukan oleh pemilik repository.

---

<div align="center">
  <h3>🌈 Viana Studio© By Rasya</h3>
  <p><b>WACPP2 — WhatsApp C++ Library</b></p>
  <p><i>Masih awal. Masih berkembang. Yang penting terus ngoding. 🚀</i></p>
</div>
