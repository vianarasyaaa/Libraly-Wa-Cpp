// Viana Studio© By Rasya
#pragma once

#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "wa/common.hpp"

namespace wa::binary {

struct Node;
using NodeList = std::vector<Node>;
using Attrs = std::vector<std::pair<std::string, std::string>>;

// Satu node XML-ish WhatsApp: tag, atribut, dan isi (kosong | anak-anak | byte).
struct Node {
    std::string tag;
    Attrs attrs;
    std::variant<std::monostate, NodeList, Bytes, std::string> content;

    [[nodiscard]] std::optional<std::string_view> attr(std::string_view key) const;
    [[nodiscard]] const NodeList* children() const;
    [[nodiscard]] const Bytes* data() const;
    [[nodiscard]] const std::string* str() const;
    [[nodiscard]] Bytes payload() const;  // isi sebagai byte (dari teks maupun biner)
    [[nodiscard]] const Node* child(std::string_view child_tag) const;
    [[nodiscard]] std::string text() const;
};

Node make_node(std::string tag, Attrs attrs = {});
Node make_node(std::string tag, Attrs attrs, NodeList children);
Node make_node(std::string tag, Attrs attrs, Bytes data);
Node make_text_node(std::string tag, Attrs attrs, std::string text);

// Hasil encode diawali 1 byte flag (0 = tidak terkompresi), siap dibungkus Noise frame.
Bytes encode(const Node& node);
// Menerima payload hasil dekripsi Noise (byte flag + node, zlib bila flag & 2).
Result<Node> decode(ByteView frame);

std::string dump(const Node& node, int indent = 0);

}  // namespace wa::binary
