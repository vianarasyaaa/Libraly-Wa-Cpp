// Viana Studio© By Rasya
#pragma once

#include <string_view>

#include "wa/binary.hpp"
#include "wa/common.hpp"
#include "wa/creds.hpp"

namespace wa {

// iq companion_hello: mengirim ephemeral terbungkus kode pairing ke server.
Result<binary::Node> build_companion_hello(const Creds& creds, std::string_view iq_id, std::string_view browser_os,
                                           std::string_view browser_name);

// Notifikasi link_code_companion_reg dari HP -> iq companion_finish. Mengisi creds.adv_secret_key.
Result<binary::Node> handle_link_code_notification(Creds& creds, const binary::Node& notification,
                                                   std::string_view iq_id);

// iq pair-success: verifikasi HMAC + tanda tangan akun, lalu balasan pair-device-sign.
// Mengisi creds.me_jid, platform, account, registered.
Result<binary::Node> handle_pair_success(Creds& creds, const binary::Node& stanza);

}  // namespace wa
