// Viana Studio© By Rasya
#pragma once

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <expected>
#include <format>
#include <initializer_list>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace wa {

using Bytes = std::vector<std::uint8_t>;
using ByteView = std::span<const std::uint8_t>;

enum class ErrorCode { generic, timeout, closed, protocol, crypto, io };

struct Error {
    ErrorCode code{ErrorCode::generic};
    std::string message;
};

template <class T>
using Result = std::expected<T, Error>;

inline std::unexpected<Error> fail(std::string message, ErrorCode code = ErrorCode::generic) {
    return std::unexpected<Error>(Error{code, std::move(message)});
}

// ---------------------------------------------------------------- bytes ----

inline ByteView view_of(std::string_view s) noexcept {
    return ByteView(reinterpret_cast<const std::uint8_t*>(s.data()), s.size());
}

inline Bytes to_bytes(std::string_view s) {
    const auto v = view_of(s);
    return Bytes(v.begin(), v.end());
}

inline std::string to_string(ByteView b) { return std::string(b.begin(), b.end()); }

inline Bytes concat(std::initializer_list<ByteView> parts) {
    std::size_t total = 0;
    for (const auto p : parts) total += p.size();
    Bytes out;
    out.reserve(total);
    for (const auto p : parts) out.insert(out.end(), p.begin(), p.end());
    return out;
}

inline std::string to_hex(ByteView b) {
    static constexpr char kDigits[] = "0123456789abcdef";
    std::string out;
    out.reserve(b.size() * 2);
    for (const std::uint8_t x : b) {
        out += kDigits[x >> 4];
        out += kDigits[x & 0x0F];
    }
    return out;
}

inline Result<Bytes> from_hex(std::string_view s) {
    if (s.size() % 2 != 0) return fail("hex: panjang ganjil");
    auto nib = [](char c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    };
    Bytes out;
    out.reserve(s.size() / 2);
    for (std::size_t i = 0; i < s.size(); i += 2) {
        const int hi = nib(s[i]);
        const int lo = nib(s[i + 1]);
        if (hi < 0 || lo < 0) return fail("hex: karakter tidak valid");
        out.push_back(static_cast<std::uint8_t>((hi << 4) | lo));
    }
    return out;
}

inline std::string base64_encode(ByteView data) {
    static constexpr std::string_view kAlpha =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string out;
    out.reserve((data.size() + 2) / 3 * 4);
    std::size_t i = 0;
    for (; i + 2 < data.size(); i += 3) {
        const std::uint32_t v = (std::uint32_t(data[i]) << 16) | (std::uint32_t(data[i + 1]) << 8) | data[i + 2];
        out += kAlpha[(v >> 18) & 63];
        out += kAlpha[(v >> 12) & 63];
        out += kAlpha[(v >> 6) & 63];
        out += kAlpha[v & 63];
    }
    if (i + 1 == data.size()) {
        const std::uint32_t v = std::uint32_t(data[i]) << 16;
        out += kAlpha[(v >> 18) & 63];
        out += kAlpha[(v >> 12) & 63];
        out += "==";
    } else if (i + 2 == data.size()) {
        const std::uint32_t v = (std::uint32_t(data[i]) << 16) | (std::uint32_t(data[i + 1]) << 8);
        out += kAlpha[(v >> 18) & 63];
        out += kAlpha[(v >> 12) & 63];
        out += kAlpha[(v >> 6) & 63];
        out += '=';
    }
    return out;
}

inline Result<Bytes> base64_decode(std::string_view in) {
    Bytes out;
    std::uint32_t acc = 0;
    int bits = 0;
    for (const char c : in) {
        if (c == '=' || c == '\n' || c == '\r' || c == ' ') continue;
        int v = 0;
        if (c >= 'A' && c <= 'Z') v = c - 'A';
        else if (c >= 'a' && c <= 'z') v = c - 'a' + 26;
        else if (c >= '0' && c <= '9') v = c - '0' + 52;
        else if (c == '+') v = 62;
        else if (c == '/') v = 63;
        else return fail("base64: karakter tidak valid");
        acc = (acc << 6) | static_cast<std::uint32_t>(v);
        bits += 6;
        if (bits >= 8) {
            bits -= 8;
            out.push_back(static_cast<std::uint8_t>((acc >> bits) & 0xFF));
        }
    }
    return out;
}

// -------------------------------------------------------------- logging ----

enum class LogLevel { debug = 0, info, warn, error, off };

inline LogLevel& log_level() {
    static LogLevel level = LogLevel::info;
    return level;
}

inline void log_write(LogLevel level, std::string_view message) {
    if (level < log_level()) return;
    static constexpr std::string_view kNames[] = {"DEBUG", "INFO", "WARN", "ERROR", "OFF"};
    const auto name = kNames[static_cast<int>(level)];
    std::fprintf(stderr, "[wa:%.*s] %.*s\n", static_cast<int>(name.size()), name.data(),
                 static_cast<int>(message.size()), message.data());
}

template <class... Args>
void logf(LogLevel level, std::format_string<Args...> fmt, Args&&... args) {
    if (level < log_level()) return;
    log_write(level, std::format(fmt, std::forward<Args>(args)...));
}

// ------------------------------------------------------------- protobuf ----

namespace pb {

class Writer {
public:
    Writer& varint(std::uint32_t field, std::uint64_t value) {
        put_tag(field, 0);
        put_varint(value);
        return *this;
    }
    Writer& bytes(std::uint32_t field, ByteView value) {
        put_tag(field, 2);
        put_varint(value.size());
        buf_.insert(buf_.end(), value.begin(), value.end());
        return *this;
    }
    Writer& string(std::uint32_t field, std::string_view value) { return bytes(field, view_of(value)); }
    Writer& message(std::uint32_t field, const Writer& inner) { return bytes(field, inner.buf_); }

    [[nodiscard]] const Bytes& data() const noexcept { return buf_; }
    [[nodiscard]] Bytes take() noexcept { return std::move(buf_); }

private:
    void put_tag(std::uint32_t field, std::uint32_t wire) {
        put_varint((static_cast<std::uint64_t>(field) << 3) | wire);
    }
    void put_varint(std::uint64_t v) {
        while (v >= 0x80) {
            buf_.push_back(static_cast<std::uint8_t>(v | 0x80));
            v >>= 7;
        }
        buf_.push_back(static_cast<std::uint8_t>(v));
    }
    Bytes buf_;
};

struct Field {
    std::uint32_t number{};
    std::uint32_t wire{};
    std::uint64_t value{};  // varint / fixed32 / fixed64
    ByteView data{};        // length-delimited
};

class Reader {
public:
    explicit Reader(ByteView data) : data_(data) {}

    // nullopt = data habis dengan rapi.
    [[nodiscard]] Result<std::optional<Field>> next() {
        if (pos_ >= data_.size()) return std::optional<Field>{};
        auto key = read_varint();
        if (!key) return std::unexpected(key.error());
        Field f;
        f.number = static_cast<std::uint32_t>(*key >> 3);
        f.wire = static_cast<std::uint32_t>(*key & 7);
        switch (f.wire) {
            case 0: {
                auto v = read_varint();
                if (!v) return std::unexpected(v.error());
                f.value = *v;
                break;
            }
            case 1: return read_fixed(f, 8);
            case 5: return read_fixed(f, 4);
            case 2: {
                auto len = read_varint();
                if (!len) return std::unexpected(len.error());
                if (*len > data_.size() - pos_) return fail("protobuf: panjang melebihi data", ErrorCode::protocol);
                f.data = data_.subspan(pos_, static_cast<std::size_t>(*len));
                pos_ += static_cast<std::size_t>(*len);
                break;
            }
            default: return fail("protobuf: wire type tidak didukung", ErrorCode::protocol);
        }
        return std::optional<Field>{f};
    }

private:
    Result<std::optional<Field>> read_fixed(Field f, std::size_t n) {
        if (n > data_.size() - pos_) return fail("protobuf: fixed terpotong", ErrorCode::protocol);
        std::uint64_t v = 0;
        for (std::size_t i = 0; i < n; ++i) v |= std::uint64_t(data_[pos_ + i]) << (8 * i);
        pos_ += n;
        f.value = v;
        return std::optional<Field>{f};
    }
    Result<std::uint64_t> read_varint() {
        std::uint64_t v = 0;
        for (int shift = 0; shift < 64; shift += 7) {
            if (pos_ >= data_.size()) return fail("protobuf: varint terpotong", ErrorCode::protocol);
            const std::uint8_t b = data_[pos_++];
            v |= std::uint64_t(b & 0x7F) << shift;
            if (!(b & 0x80)) return v;
        }
        return fail("protobuf: varint terlalu panjang", ErrorCode::protocol);
    }

    ByteView data_;
    std::size_t pos_{0};
};

}  // namespace pb
}  // namespace wa
