// Viana Studio© By Rasya
#pragma once

#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "wa/common.hpp"

namespace wa {

struct WsOptions {
    std::vector<std::pair<std::string, std::string>> headers;
    int connect_timeout_ms = 15000;
    int handshake_timeout_ms = 15000;
    bool verify_tls = true;
};

enum class WsOp : std::uint8_t { text = 1, binary = 2, close = 8 };

struct WsMessage {
    WsOp op{WsOp::binary};
    Bytes data;
};

// Klien WebSocket (RFC 6455) di atas TLS OpenSSL. Pengiriman aman antar-thread;
// receive() dipanggil dari satu thread saja.
class WsClient {
public:
    WsClient();
    ~WsClient();
    WsClient(const WsClient&) = delete;
    WsClient& operator=(const WsClient&) = delete;

    Result<void> connect(std::string_view url, const WsOptions& options = {});
    Result<void> send_binary(ByteView data);
    Result<void> send_text(std::string_view text);
    // timeout_ms < 0 = tunggu selamanya. Timeout -> ErrorCode::timeout.
    Result<WsMessage> receive(int timeout_ms = -1);
    void close(std::uint16_t code = 1000);
    [[nodiscard]] bool connected() const;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

}  // namespace wa
