// Viana Studio© By Rasya
#pragma once

#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include "wa/binary.hpp"
#include "wa/common.hpp"
#include "wa/creds.hpp"
#include "wa/crypto.hpp"

namespace wa::sig {

struct SkippedKey {
    std::uint32_t counter{};
    Bytes seed;  // HMAC(chainKey, 0x01)
};

struct Chain {
    Bytes ratchet_key;       // 32 byte
    Bytes chain_key;         // 32 byte
    std::int64_t index{-1};  // counter terakhir yang sudah dipakai
    bool sending{false};
    std::vector<SkippedKey> skipped;
};

// Data X3DH yang harus ikut di pkmsg sampai lawan bicara membalas.
struct PendingPreKey {
    bool active{false};
    std::uint32_t signed_id{0};
    bool has_prekey{false};
    std::uint32_t prekey_id{0};
    Bytes base_key;  // 32 byte
};

struct Session {
    Bytes remote_identity;  // 32 byte (tanpa prefiks 0x05)
    Bytes base_key;         // 32 byte
    Bytes root_key;
    crypto::KeyPair our_ratchet;
    Bytes last_remote_ratchet;
    std::uint32_t previous_counter{0};
    std::uint32_t registration_id{0};
    std::vector<Chain> chains;
    bool open{true};
    PendingPreKey pending;
};

struct PreKey {
    std::uint32_t id{};
    crypto::KeyPair pair;
};

// Bundel kunci publik milik perangkat tujuan (hasil iq encrypt/get).
struct PreKeyBundle {
    std::string jid;
    std::uint32_t registration_id{0};
    Bytes identity;  // 32 byte
    std::uint32_t signed_id{0};
    Bytes signed_pub;  // 32 byte
    Bytes signed_sig;  // 64 byte
    bool has_prekey{false};
    std::uint32_t prekey_id{0};
    Bytes prekey_pub;  // 32 byte
};

struct Encrypted {
    bool prekey_message{false};  // true -> enc type "pkmsg", false -> "msg"
    Bytes data;
};

// Prekey sekali pakai + sesi Signal per alamat (JID pengirim). Disimpan sebagai teks (izin 0600).
class Store {
public:
    explicit Store(std::string path) : path_(std::move(path)) {}

    Result<void> load();
    Result<void> save() const;

    std::vector<PreKey> generate_prekeys(std::size_t count);
    [[nodiscard]] const PreKey* find_prekey(std::uint32_t id) const;
    void remove_prekey(std::uint32_t id);
    [[nodiscard]] std::size_t prekey_count() const noexcept { return prekeys_.size(); }

    std::vector<Session>& sessions(const std::string& address) { return sessions_[address]; }

private:
    std::string path_;
    std::uint32_t next_prekey_id_{1};
    std::map<std::uint32_t, PreKey> prekeys_;
    std::map<std::string, std::vector<Session>> sessions_;
};

class Cipher {
public:
    Cipher(Store& store, const Creds& creds) : store_(store), creds_(creds) {}

    // type: "pkmsg" atau "msg". Hasil = plaintext (masih berpadding WA).
    Result<Bytes> decrypt(const std::string& address, std::string_view type, ByteView ciphertext);

    // --- sisi pengirim ---
    [[nodiscard]] bool has_session(const std::string& address);  // ada sesi terbuka?
    Result<void> init_outgoing(const std::string& address, const PreKeyBundle& bundle);
    Result<Encrypted> encrypt(const std::string& address, ByteView plaintext);

private:
    Result<Bytes> decrypt_prekey(const std::string& address, ByteView message);
    Result<Bytes> decrypt_whisper(const std::string& address, ByteView message);

    Store& store_;
    const Creds& creds_;
};

binary::Node build_prekey_count_query(std::string_view iq_id);
binary::Node build_prekey_upload(const Creds& creds, const std::vector<PreKey>& keys, std::string_view iq_id);
// Permintaan kirim ulang untuk pesan yang gagal didekripsi. key != nullptr -> sertakan bundel kunci baru.
binary::Node build_retry_receipt(const Creds& creds, const binary::Node& message, int count, const PreKey* key);

}  // namespace wa::sig
