// Viana Studio© By Rasya
#pragma once

#include <string_view>

#include "wa/common.hpp"
#include "wa/creds.hpp"

namespace wa {

// Versi WA Web, mis. 2.3000.1015901307 (bagian ketiga = client_revision terbaru).
struct WaVersion {
    std::uint32_t primary{2};
    std::uint32_t secondary{3000};
    std::uint32_t tertiary{0};
};

Result<WaVersion> parse_version(std::string_view text);

// ClientPayload (protobuf) untuk perangkat yang belum terdaftar.
Result<Bytes> build_registration_payload(const Creds& creds, const WaVersion& version, std::string_view browser_os);
// ClientPayload untuk perangkat yang sudah ditautkan (login ulang).
Result<Bytes> build_login_payload(const Creds& creds, const WaVersion& version);

}  // namespace wa
